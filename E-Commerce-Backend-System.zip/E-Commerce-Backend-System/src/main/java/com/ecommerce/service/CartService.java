package com.ecommerce.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.entity.Cart;
import com.ecommerce.entity.User;
import com.ecommerce.repository.CartRepository;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    // Add item to cart
    public Cart addToCart(Cart cart) {
        return cartRepository.save(cart);
    }

    // Get all cart items of user
    public List<Cart> getCartItems(User user) {
        return cartRepository.findByUser(user);
    }

    // Remove cart item
    public void removeCartItem(Long cartId) {
        cartRepository.deleteById(cartId);
    }

	

	
}