package com.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.ecommerce.entity.Cart;
import com.ecommerce.entity.User;
import com.ecommerce.repository.UserRepository;
import com.ecommerce.service.CartService;

@RestController
@RequestMapping("/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    @Autowired
    private UserRepository userRepository;

    // Add Product To Cart
    @PostMapping("/add")
    public Cart addToCart(@RequestBody Cart cart) {

        return cartService.addToCart(cart);
    }

    // View User Cart
    @GetMapping("/user/{userId}")
    public List<Cart> getCartItems(
            @PathVariable Long userId) {

        User user = userRepository.findById(userId)
                .orElseThrow();

        return cartService.getCartItems(user);
    }

    // Remove Cart Item
    @DeleteMapping("/{cartId}")
    public String removeCartItem(
            @PathVariable Long cartId) {

        cartService.removeCartItem(cartId);

        return "Item Removed Successfully";
    }
}