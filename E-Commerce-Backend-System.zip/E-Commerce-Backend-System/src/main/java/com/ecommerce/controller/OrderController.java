package com.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.ecommerce.entity.Order;
import com.ecommerce.entity.User;
import com.ecommerce.repository.UserRepository;
import com.ecommerce.service.OrderService;

@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private UserRepository userRepository;

    // Place Order
    @PostMapping("/place")
    public Order placeOrder(
            @RequestBody Order order) {

        return orderService.placeOrder(order);
    }

    // Order History
    @GetMapping("/user/{userId}")
    public List<Order> getOrders(
            @PathVariable Long userId) {

        User user = userRepository.findById(userId)
                .orElseThrow();

        return orderService.getOrders(user);
    }
}