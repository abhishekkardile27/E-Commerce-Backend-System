package com.ecommerce.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.ecommerce.entity.Product;
import com.ecommerce.service.ProductService;



@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    ProductService productService;

    @PostMapping
    public Product addProduct(
            @RequestBody Product product){

        return productService.save(product);
    }

    @GetMapping
    public List<Product> getProducts(){

        return productService.getAllProducts();
    }
}