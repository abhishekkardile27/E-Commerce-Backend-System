package com.ecommerce.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.ecommerce.entity.User;
import com.ecommerce.repository.UserRepository;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    // User Registration
    @PostMapping("/register")
    public String registerUser(@RequestBody User user) {

        user.setRole("USER");

        userRepository.save(user);

        return "User Registered Successfully";
    }
}