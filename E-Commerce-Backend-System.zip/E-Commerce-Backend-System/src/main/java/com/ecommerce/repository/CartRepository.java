package com.ecommerce.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ecommerce.entity.Cart;
import com.ecommerce.entity.User;

@Repository
public interface CartRepository extends JpaRepository<Cart, Long> {

    // Get all cart items of a user
    List<Cart> findByUser(User user);

	void deleteById(Long cartId);

}