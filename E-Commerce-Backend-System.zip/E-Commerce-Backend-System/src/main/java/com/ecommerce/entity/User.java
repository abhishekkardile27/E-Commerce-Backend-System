package com.ecommerce.entity;

import org.jspecify.annotations.Nullable;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name="users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @Column(unique = true)
    private String email;

    private String password;

    private String role;

	public String getEmail() {
		// TODO Auto-generated method stub
		return null;
	}

	public @Nullable String getPassword() {
		// TODO Auto-generated method stub
		return null;
	}

}
